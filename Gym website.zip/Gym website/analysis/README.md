# Project analysis

Place the deliverables of your project analysis in this folder.

-   Project description
-   User stories
-   Domain model
-   Entity-relationship diagram
