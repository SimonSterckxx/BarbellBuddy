# Getting started with the front-end

Yes, this folder is still empty. You will start working on the front-end in the third lesson.
