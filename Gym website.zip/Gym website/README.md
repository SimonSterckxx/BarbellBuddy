# Project template

To get started, open the Readme.md files in the analysis, back-end and front-end folders.

Change this readme file to describe your project, change the title and fill in your name below.

### \<Student 1 name\> / \<Student 2 name\>
